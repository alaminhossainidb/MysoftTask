export class Info {
    id : number
    name : String
    code : String
    fatherName : String
    motherName : String
    image : String
}
