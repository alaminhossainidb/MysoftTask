import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { SubSink } from 'subsink';
import { InfoService } from '../info.service';
import { Info } from '../model/info.model';

export interface Infos{
  id : Number
  code : String
  name : String
  fatherName : String
  motherName : String
  image : String

}

@Component({
  selector: 'app-information',
  templateUrl: './information.component.html',
  styleUrls: ['./information.component.css']
})
export class InformationComponent implements OnInit {
  subs = new SubSink;
  listInfo : Infos[] = []
  infoForm!: FormGroup;
  selectedFile: any = null;

  cardShow : boolean = true;
  addInfoShow : boolean = false;

  constructor(private infoService : InfoService, private formBuilder : FormBuilder) { }

informations : Info;
information : Info;

  ngOnInit() {

    this.infoForm = this.formBuilder.group({
      id: 0,
      code: [''],
      name: [''],
      fatherName: [''],
      motherName: [''],
      image: ['']
    })
    this.subs.add(this.infoService.getAll().subscribe( (res) => {
      this.listInfo = res;
    },
    (err) =>{
      console.log(err)
    }
    ))
  }

  addInfo() : void {
    this.cardShow = false;
    this.addInfoShow = true;
  }

  showInfo() : void {
    this.cardShow = true;
    this.addInfoShow = false;
  }

  public saveImage(event: any): void {
    console.log(event);
    this.selectedFile = event;
    this.infoForm.get("image").setValue(this.selectedFile.target.files[0].name);  
    
  }

  public saveInfo(): void {
    console.log("Save Hit")
    const file: File = this.selectedFile.target.files[0];
    const code = this.infoForm.get("code").value;

    this.subs.add(this.infoService.saveImage(file, code).subscribe((res) => {
      console.log('image uploaded...');
    },
    (err) => {
      console.log(err);
    }))

    var str = new String(this.infoForm.get('image').value);
    var index = str.lastIndexOf('.');
    
    str = './assets/images/' + this.infoForm.get('code').value + str.substring(index, str.length);
    this.infoForm.get('image').setValue(str);
    
    this.selectedFile = null;

    this.subs.add(this.infoService.saveInfo(this.infoForm.value).subscribe( (res) => {
      alert("data saved successfully");
      this.infoForm.reset();
    },
    (err) => {
      console.log(err);
    }))
    this.cardShow = true;
    this.addInfoShow = false;  
    
  }

  deleteInfo(id: number): void {
    this.subs.add(this.infoService.deleteInfo(id).subscribe((res) => {
      alert("Information deleted");
    },
    (err) => {
      console.log("problem in deleting Information...");
    }))
    this.cardShow = true;
    this.addInfoShow = false;
  }

  public editInfo(info: Infos): void {
    
    this.infoForm.patchValue(info);
    this.cardShow = false;
    this.addInfoShow = true;
   
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }
  
}
