import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Info } from './model/info.model';
import { Infos } from './information/information.component';

@Injectable({
  providedIn: 'root'
})
export class InfoService {

  constructor(private http : HttpClient) { }

  url : String = "http://localhost:8080/"

  public getAll() : Observable<Infos[]>{
    return this.http.get<Infos[]>(this.url+'getAll')
  }

  public saveInfo(info: Infos): Observable<Infos> {
    return this.http.post<Infos>(this.url + 'save', info);
  }

  public deleteInfo(id: number): Observable<any> {
    return this.http.delete<any>(this.url + 'delete/' + id);
  }

  public saveImage(file: File, userCode: String): Observable<any> {
    const formData = new FormData();

    formData.append('file', file);
    return this.http.post<any>(this.url + "upload-image/" + userCode, formData);
  }

 
}
